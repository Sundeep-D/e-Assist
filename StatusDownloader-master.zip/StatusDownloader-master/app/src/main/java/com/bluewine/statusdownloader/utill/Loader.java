package com.bluewine.statusdownloader.utill;

import android.util.Log;

public class Loader {


    String[] imagieFiles;

    public void loadImages(String path){

        Log.e("path",path);
        System.out.println(path);

    }
}
