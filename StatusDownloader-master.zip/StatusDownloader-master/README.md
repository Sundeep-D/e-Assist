# StatusDownloader(Whatsapp Status Downloader)

Overview
---
If you are wondering how can you download pictures and videos from WhatsApp Statuses. This free application will enable you to download videos and photos posted by your friends easily and keep them on your gallery.

Status Saver for WhatsApp, is a free application that allows you to download WhatsApp images and videos to your mobile phone.

</br>


How do I use the Status Saver application?

-	Open the application on your phone
-	Click on WhatsApp icon at the top of the screen
-	Open recent WhatsApp statues page
-	Go back to the application of Status Saver again and you will find the statuses visible 
on the main screen
-	Select WhatsApp status you want to save
-	Click the download button below the image or video
-	Press the Gallery button to find the cases you have downloaded


